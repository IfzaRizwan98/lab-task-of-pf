#include <iostream>
#include <string>
using namespace std;
struct Ticket {
    int ticketID;
    string passengerName;
    string flightName;
    string departureDate;
    string destination;
    bool isBooked;
};
void onlineticketbooking(Ticket tickets[], int &ticketCount) {
    Ticket newTicket;
    cout<<"*************************************************"<<endl;
    cout<<endl<<endl;
    cout<<"`````````````````````````````````````````````````"<<endl;
    cout<<endl<<endl;
    cout<<"*****WELCOME TO ONLINE TICKET BOOKING SYSTEM*****"<<endl;
    cout<<endl<<endl;
    cout<<"`````````````````````````````````````````````````"<<endl;
    cout<<endl<<endl;
    cout<<"*************************************************"<<endl;
    system("pause");
			system("cls");
    cout << "Enter ticket ID: ";
    cin >> newTicket.ticketID;
    cin.ignore(); 
    
    cout << "Enter passenger name: ";
    getline(cin, newTicket.passengerName);
    
    cout << "Enter flight name: ";
    getline(cin, newTicket.flightName);
    
    cout << "Enter departure date (dd/mm/yyyy): ";
    getline(cin, newTicket.departureDate);
    
    cout << "Enter destination: ";
    getline(cin, newTicket.destination);
    
    newTicket.isBooked = true;
    tickets[ticketCount] = newTicket;
    ticketCount++;
    cout << "Ticket booked successfully!" << endl;
    
}
void viewTickets(Ticket tickets[], int ticketCount) {
	cout<<"**************************************"<<endl;
	cout<<endl<<endl;
	cout<<"``````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"*****WELCOME TO VIEWTICKET SYSTEM*****"<<endl;
	cout<<endl<<endl;
    cout<<"``````````````````````````````````````"<<endl;
    cout<<endl<<endl;
    cout<<"**************************************"<<endl;
    if (ticketCount == 0) {
        cout << "Sorry!No tickets booked yet." << endl;
        
    }
    
    for (int i = 0; i < ticketCount; i++) {
        cout << "Ticket ID: " << tickets[i].ticketID << endl;
        cout << "Passenger Name: " << tickets[i].passengerName << endl;
        cout << "Flight Name: " << tickets[i].flightName << endl;
        cout << "Departure Date: " << tickets[i].departureDate << endl;
        cout << "Destination: " << tickets[i].destination << endl;
        cout << "Booking Status: " << (tickets[i].isBooked ? "Booked" : "Not Booked") << endl;
        cout << "**********************************" << endl;
    }
}
void updateTicket(Ticket tickets[], int ticketCount) {
	cout<<"****************************************"<<endl;
	cout<<endl<<endl;
	cout<<"````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"*****WELCOME TO UPDATETICKET SYSTEM*****"<<endl;
	cout<<endl<<endl;
	cout<<"````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"****************************************"<<endl;
	system("pause");
			system("cls");
    int id;
    cout << "Enter ticket ID to update: ";
    cin >> id;
    
    for (int i = 0; i < ticketCount; i++) {
        if (tickets[i].ticketID == id) {
            cout << "Enter new passenger name: ";
            cin.ignore();
            getline(cin, tickets[i].passengerName);
            
            cout << "Enter new flight name: ";
            getline(cin, tickets[i].flightName);
            
            cout << "Enter new departure date (dd/mm/yyyy): ";
            getline(cin, tickets[i].departureDate);
            
            cout << "Enter new destination: ";
            getline(cin, tickets[i].destination);
            
            cout << "Ticket updated successfully!" << endl;
            return;
        }
    }
    cout << "Oops!something went wrong.Ticket ID not found!" << endl;
}
void deleteTicket(Ticket tickets[], int &ticketCount) {
	cout<<"****************************************"<<endl;
	cout<<endl<<endl;
	cout<<"````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"*****WELCOME TO DELETETICKET SYSTEM*****"<<endl;
	cout<<endl<<endl;
	cout<<"````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"****************************************"<<endl;
	system("pause");
			system("cls");
    int id;
    cout << "Enter ticket ID to delete: ";
    cin >> id;
    
    for (int i = 0; i < ticketCount; i++) {
        if (tickets[i].ticketID == id) {
            for (int j = i; j < ticketCount - 1; j++) {
                tickets[j] = tickets[j + 1]; 
            }
            ticketCount--;
            cout << "Ticket deleted successfully!" << endl;
            return;
        }
    }
    cout << "Oops!something went wrong .Ticket ID not found!" << endl;
}
void flightmanagenment()
{
	cout<<"*****************************************************************"<<endl;
	cout<<endl<<endl;
	cout<<"`````````````````````````````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"***************WELCOME TO FLIGHT MANAGENMNET SYSTEM:*************"<<endl;
	cout<<endl<<endl;
	cout<<"`````````````````````````````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"*****************************************************************"<<endl;
	cout<<endl<<endl;
	system("pause");
			system("cls");
	cout<<"This week total 20 flights will take off this month:"<<endl;
	int count =1,time=3, date=5;
	for(int i=1;i<=5;i++)
	{
		cout<<"Flight"<<" "<<count<<" "<<"will take off at"<<" "<<time<<" "<<"PM"<<" on"<<" "<<date<<" "<<"December 2024"<<" "<<"From ISLAMABAD TO AMERICA:"<<endl;
		count++;time++;date++;
	}
		cout<<"***********************************************************************************"<<endl;
	cout<<"```````````````````````````````````````````````````````````````````````````````````"<<endl;
		cout<<"***********************************************************************************"<<endl;
	cout<<endl<<endl;
	int num =5,tim=9,dt =10;
	for(int i=5;i<=10;i++)
	{
		cout<<"Flight"<<" "<<num<<" "<<"will take off at"<<" "<<tim<<" "<<"AM"<<" on"<<" "<<dt<<" "<<"December 2024"<<" "<<"From ISLAMABAD TO CANADA:"<<endl;
		num++;tim++;dt++;
	}	cout<<"***********************************************************************************"<<endl;
	cout<<"```````````````````````````````````````````````````````````````````````````````````"<<endl;
		cout<<"***********************************************************************************"<<endl;
	cout<<endl<<endl;
	int number =10,tm=2,da=16;
	for(int i=10;i<=15;i++)
	{
		cout<<"Flight"<<" "<<number<<" "<<"will take off at"<<" "<<tm<<" "<<"PM"<<" on"<<" "<<da<<" "<<"December 2024"<<"  "<<"From ISLAMABAD TO DUBAI:"<<endl;
		number++;tm++;da++;
	}
	cout<<"***********************************************************************************"<<endl;
	cout<<"```````````````````````````````````````````````````````````````````````````````````"<<endl;
	cout<<"***********************************************************************************"<<endl;
	cout<<endl<<endl;
	int start=15,hr=1,d=22;
	for(int i=15;i<=20;i++)
	{
		cout<<"Flight"<<" "<<start<<" "<<"will take off at"<<" "<<hr<<" "<<"AM"<<" on"<<" "<<d<<" "<<" December 2024"<<" "<<"From ISLAMABAD TO TURKEY"<<endl;
		start++;hr;d++;
	}
		cout<<"***********************************************************************************"<<endl;
	cout<<"```````````````````````````````````````````````````````````````````````````````````"<<endl;
	cout<<"***********************************************************************************"<<endl;
}
void passengermanagenment()
{
     cout<<"*************************************************************************"<<endl;
     cout<<endl<<endl;
     cout<<"`````````````````````````````````````````````````````````````````````````"<<endl;
     cout<<endl<<endl;
     cout<<"*******************WELCOME TO PASSENGERMANAGENMENT***********************"<<endl;
     cout<<endl<<endl;
     cout<<"`````````````````````````````````````````````````````````````````````````"<<endl;
     cout<<endl<<endl;
     cout<<"*************************************************************************"<<endl;
     cout<<endl<<endl;
     system("pause");
			system("cls");
	cout<<"There are 200 seats in flight 1 to 5 which will take off From ISLAMABAD TO AMERICA: "<<endl;
	cout<<"`````````````````````````````````````````````````````````````````````````````````````"<<endl;
	cout<<"100 seats are in noraml class "<<endl;
	cout<<"``````````````````````````````"<<endl;
	cout<<"100 seats are in business class"<<endl;
	cout<<"````````````````````````````````"<<endl;
	cout<<"First 30 seats from business class are reserved:"<<endl;
	cout<<"````````````````````````````````````````````````"<<endl;
	cout<<"first 45 seats from normal class are reserved:"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"*************************************************************************"<<endl;
     cout<<"`````````````````````````````````````````````````````````````````````````"<<endl;
     cout<<"*************************************************************************"<<endl;
	cout<<"There are 200 seats in flight 5 to 10 which will take off   From ISLAMABAD TO CANADA:"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"100 seats are in noraml class "<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"100 seats are in business class "<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"First 30 seats from business class are reserved:"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"first 45 seats from normal class are reserved:"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"There are 100 seats in flight"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"*************************************************************************"<<endl;
     cout<<"`````````````````````````````````````````````````````````````````````````"<<endl;
     cout<<"*************************************************************************"<<endl;	
	cout<<"There are 200 seats in flight 10 to 15 which will take off From ISLAMABAD TO DUBAI: "<<endl;
	cout<<"100 seats are in noraml class "<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"100 seats are in business class "<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"First 30 seats from business class are reserved:"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"first 45 seats from normal class are reserved:"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"*************************************************************************"<<endl;
     cout<<"`````````````````````````````````````````````````````````````````````````"<<endl;
     cout<<"*************************************************************************"<<endl;
	cout<<"There are 200 seats in flight 15 to 20 which will take off From ISLAMABAD TO TURKEY :"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"100 seats are in noraml class "<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"100 seats are in business class "<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"First 30 seats from business class are reserved:"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<"first 45 seats from normal class are reserved:"<<endl;
	cout<<"``````````````````````````````````````````````"<<endl;
	cout<<endl<<endl;
	cout<<"which class you want to book?business class or normal class?"<<endl;
	cout<<"If you want to book business class please press 1"<<endl;
	cout<<"If you want to book normal class  please press 2"<<endl;
	int clas;double flight=40;
	cin>>clas;
	switch(clas)
	{
		case 1:{
		cout<<"**************WELCOME TO BUSINESS CLASS*************"<<endl;
			cout<<"````````````````````````````````````````````````````"<<endl;
			cout<<"****************************************************"<<endl;
			cout<<"There are only 70 seats avalible in business class:"<<endl;
			system("pause");
			system("cls");
			cout<<"Enter any number for check seat is avalible or not?"<<endl;
			cin>>flight;
			if(flight>=30&&flight<=100)
			{
				cout<<"seats are avalible:"<<endl;
			}
			else {
			
			cout<<"Oops!sorry no seats are not avalible:"<<endl;}
			break;
		}
		case 2:
			{
				cout<<"**************WELCOME TO NORMAL CLASS***********"<<endl;
				cout<<"````````````````````````````````````````````````"<<endl;
				cout<<"***********************************************"<<endl;
				cout<<"There are only 55 seats avalible in normal:"<<endl;
				system("pause");
			system("cls");
				cout<<"Enter any number for check seat is avalible or not?"<<endl;
				cin>>flight;
				if(flight>=45&&flight<=100)
				{
					cout<<"seats are avalible:"<<endl;
				}
				else 
				{
				cout<<"Oops!seats are not avalible:"<<endl;}
				break;
			}
	}
	
	
	cout<<"*************************************************************************"<<endl;
     cout<<"`````````````````````````````````````````````````````````````````````````"<<endl;
     cout<<"*************************************************************************"<<endl;
	 cout<<endl<<endl;	
		
	
}

int main()
 {
    Ticket tickets[50]; 
    int ticketCount = 0;
    int choice;
    while(true)

     {
     	cout<<"************************************************************"<<endl;
     	cout<<endl<<endl;
    cout << "***************WELCOME TO AIRPORT MANAGEMENT  SYSTEM**********"<<endl;
    cout<<endl<<endl;
    cout<<"****************************************************************"<<endl;
    cout<<endl<<endl;
    system("pause");
			system("cls");
    cout<<"If you want to check flight managenmnet system please press 1:"<<endl;
 	cout<<"If you want to check passenger managenment system please press 2:"<<endl;
 	cout<<"If you want to book  ticket please press 3:"<<endl;
 	cout<<"If you want to verify ticket booking status please press 4:"<<endl;
 	cout<<"If you want to update your ticket please press 5:"<<endl;
 	cout<<"If you want to cancel your ticket please press 6:"<<endl;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        	
            case 1:
            	system("color F1");
            	flightmanagenment();
                break;
                case 2:
                	system("color F2");
                 passengermanagenment();
                 break;
                case 3:
                	system("color F3");
                	onlineticketbooking(tickets, ticketCount);
                	break;
                	 case 4:
                	 	system("color F4");
                viewTickets(tickets, ticketCount);
                break;
            case 5:
            	system("colour F5");
                updateTicket(tickets, ticketCount);
                break;
            case 6:
            	system("colour F6");
                deleteTicket(tickets, ticketCount);
                break;
        
            default:
            	system("colour F7");
                cout <<"Oops!Something Went Wrong Please Try Again:";
        }
    }

    return 0;
}
